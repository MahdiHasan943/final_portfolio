import React from 'react'

const Contact = () => {

  return (
    <section  id='con'>

    </section>
  )
}

export default Contact