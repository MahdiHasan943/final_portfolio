import React from 'react'

const Skills = () => {
  return (
    <section id='skill' className='bg-white'>Skills</section>
  )
}

export default Skills